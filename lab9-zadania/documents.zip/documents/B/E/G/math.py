x = 2 + 2
print(x)
