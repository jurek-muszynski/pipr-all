print("baz")
