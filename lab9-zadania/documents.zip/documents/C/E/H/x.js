let x = 2 + 2
console.log(x)